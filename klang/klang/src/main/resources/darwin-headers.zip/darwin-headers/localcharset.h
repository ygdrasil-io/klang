#ifndef _LOCALCHARSET_H
#define _LOCALCHARSET_H

#include <sys/cdefs.h>

__BEGIN_DECLS
const char *locale_charset(void);
__END_DECLS

#endif	/* _LOCALCHARSET_H */
