#ifndef _LIBCHARSET_H
#define _LIBCHARSET_H

#include <sys/cdefs.h>
#include <localcharset.h>

__BEGIN_DECLS
void libcharset_set_relocation_prefix(const char *, const char *);
__END_DECLS

#endif	/* _LIBCHARSET_H */
